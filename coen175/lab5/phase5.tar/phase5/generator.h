# ifndef GENERATOR_H
# define GENERATOR_H
# include "Scope.h"

void generateGlobals(Scope *scope);

# endif /* GENERATOR_H */

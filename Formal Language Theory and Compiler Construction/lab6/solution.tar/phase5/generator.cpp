/*
 * File:	generator.cpp
 *
 * Description:	This file contains the public and member function
 *		definitions for the code generator for Simple C.
 *
 *		Extra functionality:
 *		- putting all the global declarations at the end
 */

# include <map>
# include <vector>
# include <cassert>
# include <iostream>
# include "generator.h"
# include "machine.h"
# include "string.h"
# include "tokens.h"
# include "Tree.h"


using namespace std;

static int offset;
static string funcname, tab = "\t";
static Type character(CHAR), integer(INT), real(DOUBLE);

static ostream &operator <<(ostream &ostr, Expression *expr);

static Register *eax = new Register("%eax", "%al");
static Register *ecx = new Register("%ecx", "%cl");
static Register *edx = new Register("%edx", "%dl");
static vector<Register *> registers = {eax, ecx, edx};

static int sp = -1;
static Expression *fpstack[8];


/* These will be replaced with functions in the next phase.  They are here
   as placeholders so that Call::generate() is finished. */

# define assign(expr,reg)
# define assigntemp(expr)
# define load(expr,reg)


/*
 * Function:	push_fp_arg (private)
 *
 * Description:	Push a floating-point value onto the run-time stack.  If
 *		the expression is not on the top of the floating-point
 *		stack, then we first push it onto the stack.
 */

int push_fp_arg(Expression *expr)
{
    if (fpstack[sp] != expr) {
	cout << tab << "fldl" << tab << expr << endl;
	sp ++;
    }

    cout << tab << "subl" << tab << "$8, %esp" << endl;
    cout << tab << "fstpl" << tab << "(%esp)" << endl;

    sp --;
    return 8;
}


/*
 * Function:	push_char_arg (private)
 *
 * Description:	Push a character argument on the stack.  We must sign
 *		extend the character because all arguments are required to
 *		be a multiple of 4 bytes.
 */

static int push_char_arg(Expression *arg)
{
    if (arg->reg == nullptr)
	load(arg, getreg());

    cout << tab << "movsbl" << tab << arg << ", " << arg->reg->name() << endl;
    cout << tab << "pushl" << tab << arg->reg->name() << endl;

    assign(arg, nullptr);
    return 4;
}


/*
 * Function:	push_word_arg (private)
 *
 * Description:	Push a word argument, i.e., an integer or pointer, on the
 *		stack.  We can push a register, an immediate, or a memory
 *		reference.
 */

static int push_word_arg(Expression *arg)
{
    cout << tab << "pushl" << tab << arg << endl;

    assign(arg, nullptr);
    return 4;
}


/*
 * Function:	operator << (private)
 *
 * Description:	Convenience function for writing the operand of an
 *		expression using the output stream operator.
 */

static ostream &operator <<(ostream &ostr, Expression *expr)
{
    if (expr->reg != nullptr)
	return ostr << expr->reg;

    expr->operand(ostr);
    return ostr;
}


/*
 * Function:	Expression::operand
 *
 * Description:	Write an expression as an operand to the specified stream.
 */

void Expression::operand(ostream &ostr) const
{
    assert(offset != 0);
    ostr << offset << "(%ebp)";
}


/*
 * Function:	Identifier::operand
 *
 * Description:	Write an identifier as an operand to the specified stream.
 */

void Identifier::operand(ostream &ostr) const
{
    if (_symbol->offset == 0)
	ostr << global_prefix << _symbol->name();
    else
	ostr << _symbol->offset << "(%ebp)";
}


/*
 * Function:	Integer::operand
 *
 * Description:	Write an integer as an operand to the specified stream.
 */

void Integer::operand(ostream &ostr) const
{
    ostr << "$" << _value;
}


/*
 * Function:	Call::generate
 *
 * Description:	Generate code for a function call expression.
 *
 * 		On a 32-bit Linux platform, the stack needs to be aligned
 * 		on a 4-byte boundary.  (Online documentation seems to
 * 		suggest that 16 bytes are required, but 4 bytes seems to
 * 		work and is much easier.)  Since all arguments are a
 * 		multiple of 4 bytes, the stack will always be aligned.
 */

void Call::generate()
{
    unsigned bytes;
    Expression *arg;
    Type result;


    /* Generate code for the arguments and push them on the stack. */

    bytes = 0;

    for (int i = _args.size() - 1; i >= 0; i --) {
	arg = _args[i];

	arg->generate();

	if (arg->type() == real)
	    bytes += push_fp_arg(arg);
	else if (arg->type() == character)
	    bytes += push_char_arg(arg);
	else
	    bytes += push_word_arg(arg);
    }


    /* Spill the caller-saved registers. */

    load(nullptr, eax);
    load(nullptr, ecx);
    load(nullptr, edx);

    while (sp >= 0) {
	assigntemp(fpstack[sp]);
	cout << tab << "fstpl" << tab << fpstack[sp --] << endl;
    }


    /* Call the function and then reclaim the stack space. */

    cout << tab << "call" << tab << global_prefix << _id->name() << endl;

    if (bytes > 0)
	cout << tab << "addl" << tab << "$" << bytes << ", %esp" << endl;


    /* Save the return value. */

    result = Type(_type.specifier(), _type.indirection());

    if (result == real)
	fpstack[++ sp] = this;

    else {
	assign(this, eax);

	if (result == character)
	    cout << tab << "movsbl" << tab << "%al, %eax" << endl;
    }
}


/*
 * Function:	Block::generate
 *
 * Description:	Generate code for this block, which simply means we
 *		generate code for each statement within the block.
 */

void Block::generate()
{
    for (auto stmt : _stmts) {
	stmt->generate();

	for (auto reg : registers)
	    assert(reg->node == nullptr);

	assert(sp == -1);
    }
}


/*
 * Function:	Simple::generate
 *
 * Description:	Generate code for a simple (expression) statement, which
 *		means simply generating code for the expression.
 */

void Simple::generate()
{
    _expr->generate();

    if (_expr->type() == real) {
	cout << tab << "fstpl" << tab << "%st" << endl;
	sp --;
    } else
	assign(_expr, nullptr);
}


/*
 * Function:	Function::generate
 *
 * Description:	Generate code for this function, which entails allocating
 *		space for local variables, then emitting our prologue, the
 *		body of the function, and the epilogue.
 */

void Function::generate()
{
    int param_offset;


    /* Assign offsets to the parameters and local variables. */

    param_offset = 2 * SIZEOF_REG;
    offset = param_offset;
    allocate(offset);


    /* Generate our prologue. */

    funcname = _id->name();
    cout << global_prefix << funcname << ":" << endl;
    cout << tab << "pushl" << tab << "%ebp" << endl;
    cout << tab << "movl" << tab << "%esp, %ebp" << endl;
    cout << tab << "subl" << tab << "$" << funcname << ".size, %esp" << endl;


    /* Generate the body of this function. */

    _body->generate();


    /* Align the stack if necessary. */

    while ((offset - param_offset) % STACK_ALIGNMENT != 0)
	offset --;


    /* Generate our epilogue. */

    cout << endl << global_prefix << funcname << ".exit:" << endl;
    cout << tab << "movl" << tab << "%ebp, %esp" << endl;
    cout << tab << "popl" << tab << "%ebp" << endl;
    cout << tab << "ret" << endl << endl;

    cout << tab << ".set" << tab << funcname << ".size, " << -offset << endl;
    cout << tab << ".globl" << tab << global_prefix << funcname << endl << endl;
}


/*
 * Function:	generateGlobals
 *
 * Description:	Generate code for any global variable declarations.
 */

void generateGlobals(Scope *scope)
{
    const Symbols &symbols = scope->symbols();

    for (auto symbol : symbols)
	if (!symbol->type().isFunction()) {
	    cout << tab << ".comm" << tab << global_prefix << symbol->name();
	    cout << ", " << symbol->type().size() << endl;
	}
}


/*
 * Function:	Assignment::generate
 *
 * Description:	Generate code for an assignment statement.
 *
 *		NOT FINISHED: Only works if the right-hand side is an
 *		integer literal and the left-hand side is an integer
 *		scalar.
 */

void Assignment::generate()
{
    assert(dynamic_cast<Integer *>(_right));
    assert(dynamic_cast<Identifier *>(_left));

    cout << tab << "movl" << tab << _right << ", " << _left << endl;
}

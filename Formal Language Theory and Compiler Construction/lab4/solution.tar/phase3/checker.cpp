/*
 * File:	checker.cpp
 *
 * Description:	This file contains the public and private function and
 *		variable definitions for the semantic checker for Simple C.
 *
 *		If a symbol is redeclared, the redeclaration is discarded
 *		and the original declaration is retained.
 *
 *		Extra functionality:
 *		- inserting an undeclared symbol with the error type
 *		- optionally deleting the symbols when closing a scope
 */

# include <set>
# include <iostream>
# include "lexer.h"
# include "tokens.h"
# include "checker.h"


using namespace std;

static set<string> defined;
static Scope *current, *global;
static const Type error;

static string redefined = "redefinition of '%s'";
static string redeclared = "redeclaration of '%s'";
static string conflicting = "conflicting types for '%s'";
static string undeclared = "'%s' undeclared";


/*
 * Function:	openScope
 *
 * Description:	Create a scope and make it the new top-level scope.
 */

Scope *openScope()
{
    current = new Scope(current);

    if (global == nullptr)
	global = current;

    return current;
}


/*
 * Function:	closeScope
 *
 * Description:	Remove the top-level scope, and make its enclosing scope
 *		the new top-level scope.
 */

Scope *closeScope(bool cleanup)
{
    Scope *old = current;
    current = current->enclosing();

    if (!cleanup)
	return old;

    for (auto symbol : old->symbols()) {
	if (symbol->type().isFunction())
	    delete symbol->type().parameters();

	delete symbol;
    }

    delete old;
    return nullptr;
}


/*
 * Function:	defineFunction
 *
 * Description:	Define a function with the specified NAME and TYPE.  A
 *		function is always defined in the outermost scope.  We
 *		simply rely on declareFunction() to do most of the actual
 *		work.
 */

Symbol *defineFunction(const string &name, const Type &type)
{
    if (defined.count(name) > 0)
	report(redefined, name);

    defined.insert(name);
    return declareFunction(name, type);
}


/*
 * Function:	declareFunction
 *
 * Description:	Declare a function with the specified NAME and TYPE.  A
 *		function is always declared in the outermost scope.  Any
 *		redeclaration is discarded.
 */

Symbol *declareFunction(const string &name, const Type &type)
{
    Symbol *symbol;


    cout << name << ": " << type << endl;
    symbol = global->find(name);

    if (symbol == nullptr) {
	symbol = new Symbol(name, type);
	global->insert(symbol);

    } else {
	if (symbol->type() != type)
	    report(conflicting, name);

	delete type.parameters();
    }

    return symbol;
}


/*
 * Function:	declareVariable
 *
 * Description:	Declare a variable with the specified NAME and TYPE.  Any
 *		redeclaration is discarded.
 */

Symbol *declareVariable(const string &name, const Type &type)
{
    Symbol *symbol;


    cout << name << ": " << type << endl;
    symbol = current->find(name);

    if (symbol == nullptr) {
	symbol = new Symbol(name, type);
	current->insert(symbol);

    } else {
	if (current != global)
	    report(redeclared, name);

	else if (symbol->type() != type)
	    report(conflicting, name);
    }

    return symbol;
}


/*
 * Function:	checkIdentifier
 *
 * Description:	Check if NAME is declared.  If it is undeclared, then
 *		declare it as having the error type in order to eliminate
 *		future error messages.
 */

Symbol *checkIdentifier(const string &name)
{
    Symbol *symbol;


    symbol = current->lookup(name);

    if (symbol == nullptr) {
	report(undeclared, name);
	symbol = new Symbol(name, error);
	current->insert(symbol);
    }

    return symbol;
}

/* Link your generated assembly code for this file with global-lib.c */

int x, y, z;

int foo(void)
{
    x = 1;
    y = 2;
    z = 3;
}
